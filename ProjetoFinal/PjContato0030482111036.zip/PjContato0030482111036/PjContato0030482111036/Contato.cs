﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Data;

namespace PjContato0030482111036
{
    class Contato
    {
        // atributos
        private int idcontato;
        private string nomecontato;
        private string endcontato;
        private int cidadeidcidade;
        private string celcontato;
        private string emailcontato;
        private DateTime dtcadastrocontato;


        // propriedades
        public int Idcontato
        {
            get
            {
                return idcontato;
            }
            set
            {
                idcontato = value;
            }
        }

        public string Nomecontato
        {
            get
            {
                return nomecontato;
            }
            set
            {
                nomecontato = value;
            }
        }

        public string Endcontato
        {
            get
            {
                return endcontato;
            }
            set
            {
                endcontato = value;
            }
        }

        public int Cidadeidcidade
        {
            get
            {
                return cidadeidcidade;
            }
            set
            {
                cidadeidcidade = value;
            }
        }

        public string Celcontato
        {
            get
            {
                return celcontato;
            }
            set
            {
                celcontato = value;
            }
        }

        public string Emailcontato
        {
            get
            {
                return emailcontato;
            }
            set
            {
                emailcontato = value;
            }
        }

        public DateTime Dtcadastrocontato
        {
            get
            {
                return dtcadastrocontato;
            }
            set
            {
                dtcadastrocontato = value;
            }
        }


        // metodo que listar
        public DataTable Listar()
        {
            SqlDataAdapter daContato;
            DataTable dtContato = new DataTable();
            try
            {
                daContato = new SqlDataAdapter("SELECT * FROM CONTATO", frmPrincipal.conexao);
                daContato.Fill(dtContato);
                daContato.FillSchema(dtContato, SchemaType.Source);
            }
            catch (Exception)
            {
                throw;
            }
            return dtContato;
        }
        public int Salvar() // INCLUSAO
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("INSERT INTO CONTATO VALUES (@nomecontato,@endcontato,@cidadeidcidade," +
                "@celcontato,@emailcontato,@dtcadastrocontato)", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.Date));

                mycommand.Parameters["@nomecontato"].Value = Nomecontato;
                mycommand.Parameters["@endcontato"].Value = Endcontato;
                mycommand.Parameters["@cidadeidcidade"].Value = Cidadeidcidade;
                mycommand.Parameters["@celcontato"].Value = Celcontato;
                mycommand.Parameters["@emailcontato"].Value = Emailcontato;
                mycommand.Parameters["@dtcadastrocontato"].Value = Dtcadastrocontato;

                retorno = mycommand.ExecuteNonQuery();

            }
            catch (Exception)
            {
                throw;
            }

            return retorno;
        }
        public int Alterar() // alteração
        {
            int retorno = 0;

            try
            {
                SqlCommand mycommand;
                mycommand = new SqlCommand("UPDATE CONTATO SET NOME_CONTATO=@nomecontato,END_CONTATO=@endcontato," +
                " CIDADE_ID_CIDADE=@cidadeidcidade, CEL_CONTATO=@celcontato, EMAIL_CONTATO=@emailcontato, " +
                " DTCADASTRO_CONTATO=@dtcadastrocontato WHERE ID_CONTATO = @idcontato", frmPrincipal.conexao);

                mycommand.Parameters.Add(new SqlParameter("@idcontato", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@nomecontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@endcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@cidadeidcidade", SqlDbType.Int));
                mycommand.Parameters.Add(new SqlParameter("@celcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@emailcontato", SqlDbType.VarChar));
                mycommand.Parameters.Add(new SqlParameter("@dtcadastrocontato", SqlDbType.Date));

                mycommand.Parameters["@idcontato"].Value = Idcontato;
                mycommand.Parameters["@nomecontato"].Value = Nomecontato;
                mycommand.Parameters["@endcontato"].Value = Endcontato;
                mycommand.Parameters["@cidadeidcidade"].Value = Cidadeidcidade;
                mycommand.Parameters["@celcontato"].Value = Celcontato;
                mycommand.Parameters["@emailcontato"].Value = Emailcontato;
                mycommand.Parameters["@dtcadastrocontato"].Value = Dtcadastrocontato;

                retorno = mycommand.ExecuteNonQuery();
            }
            catch (Exception)
            {
                throw;
            }
            return retorno;
        }
        public int Excluir() // EXCLUSÃO
        {
            int nReg = 0;

            try
            {
                SqlCommand mycommand;

                mycommand = new SqlCommand("DELETE FROM CONTATO WHERE ID_CONTATO=@idcontato", frmPrincipal.conexao);
                mycommand.Parameters.Add(new SqlParameter("@idcontato", SqlDbType.Int));
                mycommand.Parameters["@idcontato"].Value = Idcontato;

                nReg = mycommand.ExecuteNonQuery();
            }

            catch (Exception)
            {
                throw;
            }

            return nReg;
        }
    }
}
